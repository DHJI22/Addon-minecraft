package ru.knocker.bridge

import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Общий лог и статус между сервисом и экраном. */
object Bus {
    private val history = ArrayList<String>()
    private val main = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Volatile var status: String = "Остановлен"
    @Volatile var running: Boolean = false
    @Volatile var logListener: (() -> Unit)? = null
    @Volatile var statusListener: (() -> Unit)? = null

    fun log(msg: String) {
        val line = fmt.format(Date()) + " " + msg
        synchronized(history) {
            history.add(line)
            while (history.size > 400) history.removeAt(0)
        }
        android.util.Log.d("KnockerBridge", msg)
        main.post { logListener?.invoke() }
    }

    fun setStatus(s: String, isRunning: Boolean) {
        status = s
        running = isRunning
        main.post { statusListener?.invoke() }
    }

    fun tail(n: Int): String = synchronized(history) {
        history.takeLast(n).joinToString("\n")
    }

    fun all(): String = synchronized(history) { history.joinToString("\n") }
}
