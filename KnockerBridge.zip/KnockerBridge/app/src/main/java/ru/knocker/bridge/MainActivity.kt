package ru.knocker.bridge

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import ru.knocker.bridge.databinding.ActivityMainBinding

class MainActivity : Activity() {
    private lateinit var b: ActivityMainBinding
    private var providerInit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        b.modeSpinner.adapter = adapter(listOf("Тест (отвечает «привет»)", "Облачный API"))
        b.providerSpinner.adapter = adapter(Presets.list.map { it.name })

        val cfg = Settings.load(this)
        b.modeSpinner.setSelection(cfg.mode)
        b.providerSpinner.setSelection(cfg.provider)
        b.urlEdit.setText(cfg.baseUrl)
        b.modelEdit.setText(cfg.model)
        b.keyEdit.hint = if (cfg.apiKey.isEmpty()) "API-ключ" else "Ключ сохранён (введи новый или «-», чтобы удалить)"
        b.personaEdit.setText(cfg.persona)
        b.playerEdit.setText(cfg.player)
        b.stateCheck.isChecked = cfg.useState
        b.wifiCheck.isChecked = cfg.bindAll

        b.providerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (!providerInit) { providerInit = true; return }
                b.urlEdit.setText(Presets.list[pos].url)
                b.modelEdit.setText(Presets.list[pos].model)
            }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }

        refreshProfiles()
        b.newProfileBtn.setOnClickListener {
            val et = EditText(this)
            et.hint = "Название, например «Мир с Аней»"
            et.setSingleLine()
            AlertDialog.Builder(this)
                .setTitle("Новый сервер")
                .setMessage("Прошлый сервер сохранится вместе с памятью Кнокера. На новом он начнёт с чистого листа.")
                .setView(et)
                .setPositiveButton("Создать") { _, _ ->
                    val p = Profiles.create(this, et.text.toString())
                    Bus.log("Создан сервер «${p.name}»: память Кнокера пустая")
                    refreshProfiles()
                }
                .setNegativeButton("Отмена", null)
                .show()
        }
        b.deleteProfileBtn.setOnClickListener {
            val list = Profiles.list(this)
            if (list.size <= 1) return@setOnClickListener
            val cur = list.first { it.id == Profiles.currentId(this) }
            AlertDialog.Builder(this)
                .setTitle("Удалить сервер «${cur.name}»?")
                .setMessage("Вся память Кнокера об этом сервере будет стёрта. Другие серверы не затронуты.")
                .setPositiveButton("Удалить") { _, _ ->
                    Profiles.delete(this, cur.id)
                    Diary(this).deleteProfile(cur.id)
                    Bus.log("Сервер «${cur.name}» удалён")
                    refreshProfiles()
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        b.startBtn.setOnClickListener {
            val c = saveFromUi()
            if (c.mode == Settings.MODE_API && c.apiKey.isBlank() && !c.baseUrl.contains("127.0.0.1")) {
                Bus.log("Внимание: режим API, а ключ не задан")
            }
            startForegroundService(Intent(this, BridgeService::class.java))
        }
        b.stopBtn.setOnClickListener {
            startService(Intent(this, BridgeService::class.java).setAction(BridgeService.ACTION_STOP))
        }
        b.copyLogBtn.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", Bus.all()))
            Toast.makeText(this, "Лог скопирован", Toast.LENGTH_SHORT).show()
        }
        b.testApiBtn.setOnClickListener {
            val c = saveFromUi()
            Bus.log("Проверка API: ${c.baseUrl} / ${c.model}")
            Thread {
                try {
                    val r = AiClient.chat(c, listOf("system" to "Ответь одним коротким словом.", "user" to "Скажи привет"))
                    Bus.log("API ок: " + r.take(80))
                } catch (e: Exception) {
                    Bus.log("API ошибка: ${e.message}")
                }
            }.start()
        }
    }

    private fun refreshProfiles() {
        val list = Profiles.list(this)
        val cur = Profiles.currentId(this)
        b.profileSpinner.onItemSelectedListener = null
        b.profileSpinner.adapter = adapter(list.map { it.name })
        b.profileSpinner.setSelection(list.indexOfFirst { it.id == cur }.coerceAtLeast(0), false)
        b.profileSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val all = Profiles.list(this@MainActivity)
                if (pos !in all.indices) return
                val sel = all[pos]
                if (sel.id != Profiles.currentId(this@MainActivity)) {
                    Profiles.setCurrent(this@MainActivity, sel.id)
                    Bus.log("Сервер: «${sel.name}» (у него своя память Кнокера)")
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }
        b.deleteProfileBtn.isEnabled = list.size > 1
    }

    private fun adapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun saveFromUi(): Cfg {
        val cfg = Cfg(
            mode = b.modeSpinner.selectedItemPosition,
            provider = b.providerSpinner.selectedItemPosition,
            baseUrl = b.urlEdit.text.toString().trim(),
            model = b.modelEdit.text.toString().trim(),
            apiKey = "",
            persona = b.personaEdit.text.toString(),
            player = b.playerEdit.text.toString().trim(),
            bindAll = b.wifiCheck.isChecked,
            useState = b.stateCheck.isChecked
        )
        val typed = b.keyEdit.text.toString()
        Settings.save(this, cfg, typed)
        if (typed.isNotBlank()) {
            b.keyEdit.setText("")
            b.keyEdit.hint = if (typed.trim() == "-") "API-ключ" else "Ключ сохранён (введи новый или «-», чтобы удалить)"
        }
        return Settings.load(this)
    }

    private fun refreshLog() {
        b.logText.text = Bus.tail(15)
    }

    private fun refreshStatus() {
        b.statusText.text = Bus.status
        b.startBtn.isEnabled = !Bus.running
        b.stopBtn.isEnabled = Bus.running
    }

    override fun onStart() {
        super.onStart()
        Bus.logListener = { refreshLog() }
        Bus.statusListener = { refreshStatus() }
        refreshLog()
        refreshStatus()
    }

    override fun onStop() {
        Bus.logListener = null
        Bus.statusListener = null
        super.onStop()
    }
}
