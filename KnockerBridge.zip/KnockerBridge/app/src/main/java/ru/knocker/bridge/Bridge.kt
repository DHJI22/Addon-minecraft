package ru.knocker.bridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Логика моста: события Minecraft (WebSocket) -> ИИ -> команды в игру. */
class Bridge(private val ctx: Context, private val cfg: Cfg) : WsListener {
    private val exec = Executors.newSingleThreadExecutor()
    private val diary = Diary(ctx)
    private val bridgeOn = HashSet<String>()
    private val msgSeq = AtomicInteger(0)
    @Volatile private var lastHint = 0L

    /** Подсказка игроку в чат игры, не чаще раза в минуту. */
    private fun hint(text: String) {
        val now = System.currentTimeMillis()
        if (now - lastHint < 60000) return
        lastHint = now
        tellraw(text)
    }

    @Volatile private var conn: WsConn? = null
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var stateJson: JSONObject? = null
    @Volatile private var scoreLatch: CountDownLatch? = null
    @Volatile private var scoreReqId: String? = null
    @Volatile private var scoreMsg: String? = null
    @Volatile private var tagLatch: CountDownLatch? = null
    @Volatile private var tagReqId: String? = null
    @Volatile private var tagMsg: String? = null

    // ---------- WsListener ----------
    override fun onConnected(c: WsConn) {
        conn = c
        synchronized(bridgeOn) { bridgeOn.clear() }
        Bus.setStatus("Игра подключена", true)
        Bus.log("Игра подключена")
        val serverName = Profiles.currentName(ctx)
        Bus.log("Память Кнокера: сервер «$serverName»")
        subscribe("PlayerMessage")
        tellraw("§a[Мост] подключено, пиши в чат")
        tellraw("§7[Мост] память Кнокера: сервер «$serverName»")
    }

    override fun onDisconnected() {
        conn = null
        Bus.setStatus("Ждём игру на порту ${BridgeService.PORT}", true)
        Bus.log("Игра отключилась")
    }

    override fun onText(t: String) {
        val j = try { JSONObject(t) } catch (e: Exception) {
            Bus.log("не JSON: " + t.take(100))
            return
        }
        val h = j.optJSONObject("header")
        val body = j.optJSONObject("body")
        when (h?.optString("messagePurpose")) {
            "event" -> if (h.optString("eventName") == "PlayerMessage" && body != null) handlePlayerMessage(body)
            "commandResponse" -> {
                val code = body?.optInt("statusCode", 0) ?: 0
                val rid = h.optString("requestId")
                if (rid.isNotEmpty() && rid == scoreReqId) {
                    scoreMsg = body?.optString("statusMessage", "")
                    scoreLatch?.countDown()
                } else if (rid.isNotEmpty() && rid == tagReqId) {
                    tagMsg = body?.optString("statusMessage", "")
                    tagLatch?.countDown()
                } else if (code != 0) Bus.log("команда: код $code ${body?.optString("statusMessage", "")}")
            }
            "error" -> Bus.log("ошибка игры: " + t.take(160))
            else -> Bus.log("? " + t.take(120))
        }
    }

    private fun handlePlayerMessage(body: JSONObject) {
        val msg = body.optString("message")
        val sender = body.optString("sender")
        val type = body.optString("type")

        val i = msg.indexOf("[ak:state]")
        if (i >= 0) {
            try { stateJson = JSONObject(msg.substring(i + 10)) } catch (e: Exception) { Bus.log("state: не разобрал") }
            latch?.countDown()
            return
        }
        if (type != "chat") {
            Bus.log("[$type] ${sender}: ${msg.take(60)}")
            return
        }
        if (msg.isBlank() || msg.startsWith("<Кнокер>") || msg.startsWith("!") || msg.startsWith("§") || sender == "External") return
        if (cfg.player.isNotBlank() && !sender.equals(cfg.player.trim(), ignoreCase = true)) {
            Bus.log("пропущено сообщение от «$sender»: в настройках указан ник «${cfg.player.trim()}» (оставь поле пустым, чтобы отвечать всем)")
            return
        }
        Bus.log("← $sender: $msg")
        val seq = msgSeq.incrementAndGet()
        exec.execute {
            try { handleChat(sender, msg, seq) } catch (e: Exception) { Bus.log("ошибка: $e") }
        }
    }

    // ---------- обработка сообщения ----------
    private fun handleChat(sender: String, text: String, seq: Int) {
        val first = synchronized(bridgeOn) { bridgeOn.add(sender) }
        if (first) command(se(sender, "bridge", "on"))
        command(se(sender, "chat", text.take(200)))

        val st = if (cfg.useState) requestState(sender) else null
        if (st != null && st.optInt("phase", 1) == 0) {
            Bus.log("фаза 0 (Наблюдатель): молчим")
            hint("§7[Мост] Кнокер пока только наблюдает издалека и не отвечает. Чтобы поговорить сразу, введи в чат: /scriptevent aiknocker:phase 1 и потом /scriptevent aiknocker:spawn")
            return
        }

        if (cfg.useState && st == null) {
            hint("§7[Мост] Не вижу ответа от аддона Кнокера. Включены ли в этом мире оба пака (AI Knocker BP и RP), и разрешены ли читы?")
        }

        if (cfg.mode == Settings.MODE_TEST) {
            tellraw("§7[Мост] услышал: $text")
            say(sender, "привет")
            return
        }

        if (seq != msgSeq.get()) {
            Bus.log("пришло новое сообщение, на это не отвечаю")
            return
        }

        val msgs = ArrayList<Pair<String, String>>()
        msgs.add("system" to Prompt.system(cfg, st, sender))
        msgs.addAll(diary.get(sender))
        msgs.add("user" to text)
        val t0 = System.currentTimeMillis()
        val raw = try {
            AiClient.chat(cfg, msgs)
        } catch (e: Exception) {
            Bus.log("API: ${e.message}")
            tellraw("§c[Мост] ИИ недоступен: " + (e.message ?: "?").take(70))
            return
        }
        Bus.log("ИИ ответил за ${(System.currentTimeMillis() - t0) / 1000.0} с")
        val acts = Regex("\\[(ЕДА|ЦВЕТОК|ЗАЩИТА|СМОТРИ)]").findAll(raw).map { it.groupValues[1] }.toList()
        val clean = TextUtil.clean(raw.replace(Regex("\\[[А-ЯЁA-Z_]{2,12}]"), ""))
        if (clean.isBlank() && acts.isEmpty()) {
            Bus.log("пустой ответ ИИ: " + raw.take(100))
            return
        }
        if (clean.isNotBlank()) diary.add(sender, text, clean)
        for ((idx, chunk) in TextUtil.chunks(clean).withIndex()) {
            if (idx > 0) Thread.sleep(1600)
            say(sender, chunk)
        }
        for (a in acts.distinct()) {
            val name = when (a) { "ЕДА" -> "food"; "ЦВЕТОК" -> "flower"; "ЗАЩИТА" -> "protect"; else -> "look" }
            Bus.log("действие: $name")
            command(se(sender, "act", name))
        }
    }

    private fun requestState(sender: String): JSONObject? {
        stateJson = null
        val l = CountDownLatch(1)
        latch = l
        command(se(sender, "state"))
        // вдруг сообщение [ak:state] всё же придёт событием чата
        l.await(250, TimeUnit.MILLISECONDS)
        latch = null
        var s = stateJson
        if (s == null) {
            // основной путь: аддон записал состояние в счёт игрока, читаем его ответом на команду
            val sl = CountDownLatch(1)
            scoreMsg = null
            scoreLatch = sl
            scoreReqId = command("scoreboard players list @s")
            sl.await(2500, TimeUnit.MILLISECONDS)
            scoreLatch = null
            s = parseScores(scoreMsg ?: "")
        }
        if (s != null) {
            // что Кнокер узнал о ней: аддон хранит ответы в тегах akf:ключ:значение
            val tl = CountDownLatch(1)
            tagMsg = null
            tagLatch = tl
            tagReqId = command("tag @s list")
            tl.await(1500, TimeUnit.MILLISECONDS)
            tagLatch = null
            val facts = parseFacts(tagMsg ?: "")
            if (facts.length() > 0) s.put("facts", facts)
        }
        if (s == null) Bus.log("состояние из игры не пришло")
        else Bus.log("состояние: фаза ${s.optInt("phase")}, ${s.optString("mood")}, очки ${s.optInt("pts")}")
        return s
    }

    private fun parseFacts(msg: String): JSONObject {
        val o = JSONObject()
        if (msg.isBlank()) return o
        for (m in Regex("akf:([a-z]+):([^\\s,\\u00a7]+)").findAll(msg)) {
            o.put(m.groupValues[1], m.groupValues[2].trim('_', '.').replace('_', ' '))
        }
        return o
    }

    private fun parseScores(msg: String): JSONObject? {
        if (msg.isBlank()) return null
        fun num(key: String): Int? {
            val m1 = Regex("(-?\\d+)\\s*\\(" + key + "\\)").find(msg)
            if (m1 != null) return m1.groupValues[1].toIntOrNull()
            val m2 = Regex(key + "[^\\d-]{0,12}(-?\\d+)").find(msg)
            return m2?.groupValues?.get(1)?.toIntOrNull()
        }
        val phase = num("ak_phase") ?: return null
        val moods = arrayOf("calm", "happy", "jealous", "sad", "angry", "sulk")
        val mood = moods[(num("ak_mood") ?: 0).coerceIn(0, moods.size - 1)]
        return JSONObject()
            .put("phase", phase)
            .put("pts", num("ak_pts") ?: 0)
            .put("mood", mood)
            .put("gifts", num("ak_gifts") ?: 0)
            .put("hugs", num("ak_hugs") ?: 0)
    }

    private fun say(sender: String, text: String) {
        Bus.log("→ $text")
        command(se(sender, "say", text))
    }

    // ---------- протокол Minecraft ----------
    /** scriptevent: команда идёт от игрока, подключившего WebSocket, адресация по имени не нужна. */
    @Suppress("UNUSED_PARAMETER")
    private fun se(name: String, id: String, payload: String = ""): String {
        val clean = payload.replace(Regex("[@\\[\\]\\n\\r]"), " ").trim()
        return ("scriptevent aiknocker:$id $clean").trim()
    }

    private fun json(o: JSONObject): String = o.toString().replace("\\/", "/")

    private fun send(o: JSONObject) {
        try { conn?.sendText(json(o)) } catch (e: Exception) { Bus.log("отправка: ${e.message}") }
    }

    private fun header(purpose: String): JSONObject = JSONObject()
        .put("version", 1)
        .put("requestId", UUID.randomUUID().toString())
        .put("messagePurpose", purpose)
        .put("messageType", "commandRequest")

    private fun subscribe(event: String) {
        send(JSONObject()
            .put("header", header("subscribe"))
            .put("body", JSONObject().put("eventName", event)))
    }

    fun command(line: String): String {
        val hdr = header("commandRequest")
        send(JSONObject()
            .put("header", hdr)
            .put("body", JSONObject()
                .put("version", 1)
                .put("commandLine", line)
                .put("origin", JSONObject().put("type", "player"))))
        return hdr.optString("requestId")
    }

    private fun tellraw(text: String) {
        val raw = JSONObject().put("rawtext", JSONArray().put(JSONObject().put("text", text)))
        command("tellraw @a " + json(raw))
    }

    /** Перед остановкой возвращаем аддон в офлайн-режим. */
    fun shutdown() {
        val names = synchronized(bridgeOn) { bridgeOn.toList() }
        for (n in names) command(se(n, "bridge", "off"))
        if (conn != null) tellraw("§7[Мост] отключён")
        try { Thread.sleep(200) } catch (e: Exception) { }
        exec.shutdownNow()
    }
}
