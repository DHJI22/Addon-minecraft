package ru.knocker.bridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Логика моста: события Minecraft (WebSocket) -> ИИ -> команды в игру. */
class Bridge(ctx: Context, private val cfg: Cfg) : WsListener {
    private val exec = Executors.newSingleThreadExecutor()
    private val diary = Diary(ctx)
    private val bridgeOn = HashSet<String>()

    @Volatile private var conn: WsConn? = null
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var stateJson: JSONObject? = null

    // ---------- WsListener ----------
    override fun onConnected(c: WsConn) {
        conn = c
        synchronized(bridgeOn) { bridgeOn.clear() }
        Bus.setStatus("Игра подключена", true)
        Bus.log("Игра подключена")
        subscribe("PlayerMessage")
        tellraw("§a[Мост] подключено, пиши в чат")
    }

    override fun onDisconnected() {
        conn = null
        Bus.setStatus("Ждём игру на порту ${BridgeService.PORT}", true)
        Bus.log("Игра отключилась")
    }

    override fun onText(t: String) {
        val j = try { JSONObject(t) } catch (e: Exception) {
            Bus.log("не JSON: " + t.take(100))
            return
        }
        val h = j.optJSONObject("header")
        val body = j.optJSONObject("body")
        when (h?.optString("messagePurpose")) {
            "event" -> if (h.optString("eventName") == "PlayerMessage" && body != null) handlePlayerMessage(body)
            "commandResponse" -> {
                val code = body?.optInt("statusCode", 0) ?: 0
                if (code != 0) Bus.log("команда: код $code ${body?.optString("statusMessage", "")}")
            }
            "error" -> Bus.log("ошибка игры: " + t.take(160))
            else -> Bus.log("? " + t.take(120))
        }
    }

    private fun handlePlayerMessage(body: JSONObject) {
        val msg = body.optString("message")
        val sender = body.optString("sender")
        val type = body.optString("type")

        val i = msg.indexOf("[ak:state]")
        if (i >= 0) {
            try { stateJson = JSONObject(msg.substring(i + 10)) } catch (e: Exception) { Bus.log("state: не разобрал") }
            latch?.countDown()
            return
        }
        if (type != "chat") {
            Bus.log("[$type] ${sender}: ${msg.take(60)}")
            return
        }
        if (msg.isBlank() || msg.startsWith("<Кнокер>") || msg.startsWith("!") || msg.startsWith("§") || sender == "External") return
        if (cfg.player.isNotBlank() && !sender.equals(cfg.player.trim(), ignoreCase = true)) return
        Bus.log("← $sender: $msg")
        exec.execute {
            try { handleChat(sender, msg) } catch (e: Exception) { Bus.log("ошибка: $e") }
        }
    }

    // ---------- обработка сообщения ----------
    private fun handleChat(sender: String, text: String) {
        val first = synchronized(bridgeOn) { bridgeOn.add(sender) }
        if (first) command(se(sender, "bridge", "on"))
        command(se(sender, "chat", text.take(200)))

        val st = if (cfg.useState) requestState(sender) else null
        if (st != null && st.optInt("phase", 1) == 0) {
            Bus.log("фаза 0 (Наблюдатель): молчим")
            return
        }

        if (cfg.mode == Settings.MODE_TEST) {
            tellraw("§7[Мост] услышал: $text")
            say(sender, "привет")
            return
        }

        val msgs = ArrayList<Pair<String, String>>()
        msgs.add("system" to Prompt.system(cfg, st, sender))
        msgs.addAll(diary.get(sender))
        msgs.add("user" to text)
        val raw = try {
            AiClient.chat(cfg, msgs)
        } catch (e: Exception) {
            Bus.log("API: ${e.message}")
            tellraw("§c[Мост] ИИ недоступен: " + (e.message ?: "?").take(70))
            return
        }
        val clean = TextUtil.clean(raw)
        if (clean.isBlank()) {
            Bus.log("пустой ответ ИИ: " + raw.take(100))
            return
        }
        diary.add(sender, text, clean)
        for ((idx, chunk) in TextUtil.chunks(clean).withIndex()) {
            if (idx > 0) Thread.sleep(1600)
            say(sender, chunk)
        }
    }

    private fun requestState(sender: String): JSONObject? {
        stateJson = null
        val l = CountDownLatch(1)
        latch = l
        command(se(sender, "state"))
        l.await(2500, TimeUnit.MILLISECONDS)
        latch = null
        val s = stateJson
        if (s == null) Bus.log("состояние из игры не пришло")
        else Bus.log("состояние: фаза ${s.optInt("phase")}, ${s.optString("mood")}")
        return s
    }

    private fun say(sender: String, text: String) {
        Bus.log("→ $text")
        command(se(sender, "say", text))
    }

    // ---------- протокол Minecraft ----------
    /** scriptevent: команда идёт от игрока, подключившего WebSocket, адресация по имени не нужна. */
    @Suppress("UNUSED_PARAMETER")
    private fun se(name: String, id: String, payload: String = ""): String {
        val clean = payload.replace(Regex("[@\\[\\]\\n\\r]"), " ").trim()
        return ("scriptevent aiknocker:$id $clean").trim()
    }

    private fun json(o: JSONObject): String = o.toString().replace("\\/", "/")

    private fun send(o: JSONObject) {
        try { conn?.sendText(json(o)) } catch (e: Exception) { Bus.log("отправка: ${e.message}") }
    }

    private fun header(purpose: String): JSONObject = JSONObject()
        .put("version", 1)
        .put("requestId", UUID.randomUUID().toString())
        .put("messagePurpose", purpose)
        .put("messageType", "commandRequest")

    private fun subscribe(event: String) {
        send(JSONObject()
            .put("header", header("subscribe"))
            .put("body", JSONObject().put("eventName", event)))
    }

    fun command(line: String) {
        send(JSONObject()
            .put("header", header("commandRequest"))
            .put("body", JSONObject()
                .put("version", 1)
                .put("commandLine", line)
                .put("origin", JSONObject().put("type", "player"))))
    }

    private fun tellraw(text: String) {
        val raw = JSONObject().put("rawtext", JSONArray().put(JSONObject().put("text", text)))
        command("tellraw @a " + json(raw))
    }

    /** Перед остановкой возвращаем аддон в офлайн-режим. */
    fun shutdown() {
        val names = synchronized(bridgeOn) { bridgeOn.toList() }
        for (n in names) command(se(n, "bridge", "off"))
        if (conn != null) tellraw("§7[Мост] отключён")
        try { Thread.sleep(200) } catch (e: Exception) { }
        exec.shutdownNow()
    }
}
