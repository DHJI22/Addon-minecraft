package ru.knocker.bridge

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class Preset(val name: String, val url: String, val model: String)

object Presets {
    val list = listOf(
        Preset("OpenAI-совместимый", "https://api.openai.com/v1", "gpt-4o-mini"),
        Preset("DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat"),
        Preset("OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini"),
        Preset("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-3.5-flash-lite,gemini-3.5-flash"),
        Preset("Ollama (127.0.0.1)", "http://127.0.0.1:11434/v1", "gemma3:4b")
    )
}

data class Cfg(
    val mode: Int,
    val provider: Int,
    val baseUrl: String,
    val model: String,
    val apiKey: String,
    val persona: String,
    val player: String,
    val bindAll: Boolean,
    val useState: Boolean
)

object Settings {
    const val MODE_TEST = 0
    const val MODE_API = 1

    private fun sp(c: Context) = c.getSharedPreferences("bridge", Context.MODE_PRIVATE)

    fun load(c: Context): Cfg {
        val p = sp(c)
        val enc = p.getString("key", "") ?: ""
        return Cfg(
            mode = p.getInt("mode", MODE_TEST),
            provider = p.getInt("provider", 0),
            baseUrl = p.getString("url", Presets.list[0].url) ?: Presets.list[0].url,
            model = p.getString("model", Presets.list[0].model) ?: Presets.list[0].model,
            apiKey = if (enc.isEmpty()) "" else Secrets.decrypt(enc),
            persona = p.getString("persona", "") ?: "",
            player = p.getString("player", "") ?: "",
            bindAll = p.getBoolean("wifi", false),
            useState = p.getBoolean("state", true)
        )
    }

    /** newKey: null или пусто = не менять, "-" = удалить. */
    fun save(c: Context, cfg: Cfg, newKey: String?) {
        val e = sp(c).edit()
        e.putInt("mode", cfg.mode)
        e.putInt("provider", cfg.provider)
        e.putString("url", cfg.baseUrl)
        e.putString("model", cfg.model)
        e.putString("persona", cfg.persona)
        e.putString("player", cfg.player)
        e.putBoolean("wifi", cfg.bindAll)
        e.putBoolean("state", cfg.useState)
        if (newKey != null && newKey.isNotBlank()) {
            if (newKey.trim() == "-") e.remove("key") else e.putString("key", Secrets.encrypt(newKey.trim()))
        }
        e.apply()
    }
}

/** Шифрование ключа через Android Keystore (AES-GCM), без внешних библиотек. */
object Secrets {
    private const val ALIAS = "knocker_bridge_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val iv = c.iv
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv + ct, Base64.NO_WRAP)
    }

    fun decrypt(s: String): String {
        return try {
            val all = Base64.decode(s, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all, 0, 12))
            String(c.doFinal(all, 12, all.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}
