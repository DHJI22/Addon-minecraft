package ru.knocker.bridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Profile(val id: String, val name: String)

/** «Серверы»: отдельная память Кнокера для каждого мира Minecraft. */
object Profiles {
    const val DEFAULT_ID = "default"

    private fun sp(c: Context) = c.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    fun list(c: Context): List<Profile> {
        val out = ArrayList<Profile>()
        try {
            val arr = JSONArray(sp(c).getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Profile(o.getString("id"), o.getString("name")))
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) out.add(Profile(DEFAULT_ID, "Основной сервер"))
        return out
    }

    private fun saveList(c: Context, list: List<Profile>) {
        val arr = JSONArray()
        for (p in list) arr.put(JSONObject().put("id", p.id).put("name", p.name))
        sp(c).edit().putString("list", arr.toString()).apply()
    }

    fun currentId(c: Context): String {
        val id = sp(c).getString("current", DEFAULT_ID) ?: DEFAULT_ID
        return if (list(c).any { it.id == id }) id else list(c)[0].id
    }

    fun currentName(c: Context): String {
        val id = currentId(c)
        return list(c).firstOrNull { it.id == id }?.name ?: "Основной сервер"
    }

    fun setCurrent(c: Context, id: String) {
        sp(c).edit().putString("current", id).apply()
    }

    fun create(c: Context, name: String): Profile {
        val list = ArrayList(list(c))
        val p = Profile("p" + System.currentTimeMillis(), name.trim().ifEmpty { "Сервер " + (list.size + 1) })
        list.add(p)
        saveList(c, list)
        setCurrent(c, p.id)
        return p
    }

    /** Удаляет сервер из списка (последний удалить нельзя) и переключается на первый из оставшихся. */
    fun delete(c: Context, id: String) {
        val list = ArrayList(list(c))
        if (list.size <= 1) return
        list.removeAll { it.id == id }
        saveList(c, list)
        if (currentId(c) == id || list.none { it.id == currentId(c) }) setCurrent(c, list[0].id)
    }
}
