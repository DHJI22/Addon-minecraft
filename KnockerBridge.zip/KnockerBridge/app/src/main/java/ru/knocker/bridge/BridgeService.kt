package ru.knocker.bridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class BridgeService : Service() {
    companion object {
        const val PORT = 19131
        const val ACTION_STOP = "ru.knocker.bridge.STOP"
        private const val CHANNEL = "bridge"
        private const val NOTIF_ID = 1
    }

    private var server: WsServer? = null
    private var bridge: Bridge? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Thread {
                stopBridge()
                Handler(Looper.getMainLooper()).post {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }.start()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        if (server == null) Thread { startBridge() }.start()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Мост Кнокера", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BridgeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Мост Кнокера работает")
            .setContentText("Порт $PORT, ждём игру")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Стоп", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    @Synchronized
    private fun startBridge() {
        if (server != null) return
        val cfg = Settings.load(this)
        val b = Bridge(applicationContext, cfg)
        val s = WsServer(PORT, cfg.bindAll, b)
        try {
            s.start()
        } catch (e: Exception) {
            Bus.log("не удалось занять порт $PORT: ${e.message}")
            Bus.setStatus("Ошибка: порт $PORT занят", false)
            return
        }
        bridge = b
        server = s
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KnockerBridge:ws").also { it.acquire() }
        Bus.log("Сервер запущен: ${if (cfg.bindAll) "0.0.0.0" else "127.0.0.1"}:$PORT, режим ${if (cfg.mode == Settings.MODE_API) "API" else "тест"}")
        Bus.setStatus("Ждём игру на порту $PORT", true)
    }

    @Synchronized
    private fun stopBridge() {
        try { bridge?.shutdown() } catch (e: Exception) { }
        try { server?.stop() } catch (e: Exception) { }
        bridge = null
        server = null
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) { }
        wake = null
        Bus.log("Остановлено")
        Bus.setStatus("Остановлен", false)
    }

    override fun onDestroy() {
        if (server != null) Thread { stopBridge() }.start()
        super.onDestroy()
    }
}
