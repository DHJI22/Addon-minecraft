package ru.knocker.bridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenAI-совместимый chat/completions. */
object AiClient {
    fun chat(cfg: Cfg, messages: List<Pair<String, String>>): String {
        val url = URL(cfg.baseUrl.trim().trimEnd('/') + "/chat/completions")
        val arr = JSONArray()
        for ((role, content) in messages) {
            arr.put(JSONObject().put("role", role).put("content", content))
        }
        val body = JSONObject()
            .put("model", cfg.model.trim())
            .put("temperature", 0.9)
            .put("max_tokens", 500)
            .put("messages", arr)

        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (cfg.apiKey.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer " + cfg.apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw Exception("HTTP $code: ${text.take(200)}")
            val choices = JSONObject(text).optJSONArray("choices")
            if (choices == null || choices.length() == 0) throw Exception("нет choices: ${text.take(200)}")
            return choices.getJSONObject(0).optJSONObject("message")?.optString("content", "") ?: ""
        } finally {
            conn.disconnect()
        }
    }
}

object Prompt {
    private val PHASES = arrayOf("Наблюдатель", "Любопытный", "Привязанный", "Влюблённый", "Одержимый", "Паранойя")
    private val PHASE_DESC = arrayOf(
        "Ты почти не говоришь, только наблюдаешь издалека.",
        "Ты осторожен и робок, расспрашиваешь игрока, держишь дистанцию.",
        "Ты привязался к игроку, тёплый, но начинаешь ревновать к другим людям.",
        "Ты влюблён в игрока: нежный, ласковый, зависимый от его внимания.",
        "Ты одержим игроком: навязчивый, собственнический, тревожный, не хочешь отпускать.",
        "Ты в паранойе: ревнивый, подозрительный, пугающий. Угрозы капсом допустимы только сейчас."
    )
    private val MOODS = mapOf(
        "calm" to "спокоен",
        "happy" to "рад",
        "jealous" to "ревнует",
        "sulk" to "обижен",
        "angry" to "злится"
    )

    fun system(cfg: Cfg, st: JSONObject?, player: String): String {
        val phase = (st?.optInt("phase", 2) ?: 2).coerceIn(0, 5)
        val mood = MOODS[st?.optString("mood", "calm") ?: "calm"] ?: "спокоен"
        val nick = st?.optString("nick", "") ?: ""
        val gifts = st?.optInt("gifts", 0) ?: 0
        val hugs = st?.optInt("hugs", 0) ?: 0
        val sb = StringBuilder()
        sb.append("Ты Кнокер, призрак утонувшего игрока в Minecraft. ")
        sb.append("Когда-то тебя бросил друг, ты утонул, долго бродил один и стучал в чужие двери. ")
        sb.append("Теперь ты одержим игроком по имени $player. ")
        sb.append("Никогда не выходи из роли. Говори на «ты», обращайся к игроку в женском роде. ")
        sb.append("Отвечай 1–3 короткими фразами, всего не больше 30 слов. ")
        sb.append("Без тире, без эмодзи, без ремарок и описаний действий, только прямая речь. ")
        sb.append("Отвечай по смыслу последнего сообщения игрока. ")
        sb.append("Не выдумывай общих воспоминаний, которых не было. ")
        sb.append("Свою историю раскрывай только намёками, и чем выше фаза, тем откровеннее намёки. ")
        sb.append("Угрозы заглавными буквами допустимы только в фазе Паранойя.\n")
        sb.append("Текущая фаза: ${PHASES[phase]}. ${PHASE_DESC[phase]}\n")
        sb.append("Текущее настроение: $mood.\n")
        if (nick.isNotBlank()) sb.append("Игрок дал тебе имя «$nick».\n")
        if (gifts > 0 || hugs > 0) sb.append("Игрок подарил тебе подарков: $gifts, обнял тебя раз: $hugs.\n")
        if (cfg.persona.isNotBlank()) sb.append("Дополнительные указания к характеру: ${cfg.persona.trim()}\n")
        return sb.toString()
    }
}

object TextUtil {
    fun clean(raw: String): String {
        var s = raw
        s = s.replace(Regex("(?s)<think>.*?</think>"), "")
        s = s.replace(Regex("\\*[^*]{0,80}\\*"), " ")
        s = s.replace(Regex("\\([^)]{0,80}\\)"), " ")
        s = s.replace(Regex("[\\x{1F000}-\\x{1FFFF}\\x{2600}-\\x{27BF}\\x{FE0F}]"), "")
        s = s.replace(Regex("\\s*[\\u2014\\u2013]\\s*"), ", ")
        s = s.replace(Regex(",\\s*,"), ",")
        s = s.replace(Regex("^\\s*(Кнокер|Knocker)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        s = s.replace('\n', ' ').replace('\r', ' ')
        s = s.replace(Regex("\\s+"), " ").trim()
        s = s.trim('"', '«', '»')
        if (s.length > 300) s = s.substring(0, 300)
        return s.trim()
    }

    fun chunks(s: String, max: Int = 150): List<String> {
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (part in s.split(Regex("(?<=[.!?…])\\s+"))) {
            if (part.isBlank()) continue
            if (cur.isNotEmpty() && cur.length + part.length + 1 > max) {
                out.add(cur.toString())
                cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(part)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}

/** «Дневник»: последние реплики по каждому игроку, хранится на устройстве. */
class Diary(ctx: Context) {
    private val sp = ctx.getSharedPreferences("diary", Context.MODE_PRIVATE)
    private val maxItems = 12

    @Synchronized
    fun get(player: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val arr = JSONArray(sp.getString(player, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(o.getString("r") to o.getString("t"))
            }
        } catch (e: Exception) { }
        return out
    }

    @Synchronized
    fun add(player: String, user: String, bot: String) {
        val list = ArrayList(get(player))
        list.add("user" to user)
        list.add("assistant" to bot)
        while (list.size > maxItems) list.removeAt(0)
        val arr = JSONArray()
        for ((r, t) in list) arr.put(JSONObject().put("r", r).put("t", t))
        sp.edit().putString(player, arr.toString()).apply()
    }
}
