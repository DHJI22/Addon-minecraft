package ru.knocker.bridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiHttpException(val code: Int, val body: String) : Exception("HTTP $code: ${body.take(200)}")

/** OpenAI-совместимый chat/completions. */
object AiClient {
    /**
     * В поле модели можно указать несколько через запятую: при перегрузке, исчерпанной квоте
     * или ошибке «модель не найдена» приложение переходит к следующей. Сбои DNS повторяются
     * до 5 раз (запросы при этом не тратятся).
     */
    fun chat(cfg: Cfg, messages: List<Pair<String, String>>): String {
        val models = cfg.model.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (models.isEmpty()) throw Exception("не указана модель")
        var last: Exception = Exception("неизвестная ошибка")
        val started = System.currentTimeMillis()
        for ((mi, model) in models.withIndex()) {
            var netTries = 0
            var httpTries = 0
            while (true) {
                if (System.currentTimeMillis() - started > 30000) throw Exception("ИИ не отвечает дольше 30 секунд, плохая связь")
                try {
                    return chatOnce(cfg, model, messages)
                } catch (e: ApiHttpException) {
                    last = e
                    if (e.code == 401 || e.code == 403) throw e
                    val daily = e.code == 429 && (e.body.contains("PerDay") || e.body.contains("per day", ignoreCase = true))
                    if (daily) {
                        Bus.log("$model: суточная квота исчерпана" + if (mi < models.size - 1) ", пробую следующую" else "")
                        break
                    }
                    if (e.code == 404 || e.code == 400) {
                        Bus.log("$model: HTTP ${e.code}" + if (mi < models.size - 1) ", пробую следующую" else "")
                        if (mi == models.size - 1) throw e
                        break
                    }
                    if (httpTries < 1) {
                        httpTries++
                        Bus.log("$model: HTTP ${e.code}, повтор через 2 с")
                        Thread.sleep(2000)
                        continue
                    }
                    Bus.log("$model: HTTP ${e.code}" + if (mi < models.size - 1) ", пробую следующую" else "")
                    break
                } catch (e: java.io.IOException) {
                    last = e
                    if (netTries >= 4) throw e
                    netTries++
                    Bus.log("сеть ($netTries/4): ${e.message?.take(50)}")
                    Thread.sleep(1500)
                }
            }
        }
        val l = last
        if (l is ApiHttpException && l.code == 429) throw Exception("лимит запросов исчерпан для всех указанных моделей")
        if (l is ApiHttpException && l.code >= 500) throw Exception("Gemini перегружен, попробуй через минуту")
        throw l
    }

    private fun chatOnce(cfg: Cfg, model: String, messages: List<Pair<String, String>>): String {
        val base = cfg.baseUrl.trim().trimEnd('/')
        val url = URL(base + "/chat/completions")
        val arr = JSONArray()
        for ((role, content) in messages) {
            arr.put(JSONObject().put("role", role).put("content", content))
        }
        val gemini = base.contains("generativelanguage")
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 1.0)
            // у Gemini 2.5 «размышления» тоже считаются в лимит, поэтому он нужен большой
            .put("max_tokens", if (gemini) 2048 else 500)
            .put("messages", arr)
        if (gemini) body.put("reasoning_effort", "low")

        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 25000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (cfg.apiKey.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer " + cfg.apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiHttpException(code, text)
            val choices = JSONObject(text).optJSONArray("choices")
            if (choices == null || choices.length() == 0) throw Exception("нет choices: ${text.take(200)}")
            return choices.getJSONObject(0).optJSONObject("message")?.optString("content", "") ?: ""
        } finally {
            conn.disconnect()
        }
    }
}

object Prompt {
    private val PHASES = arrayOf("Наблюдатель", "Любопытный", "Привязанный", "Влюблённый", "Одержимый", "Паранойя")
    private val PHASE_DESC = arrayOf(
        "Ты почти не говоришь, только наблюдаешь издалека. Отвечаешь шёпотом, обрывками.",
        "Ты осторожен и робок. Отвечаешь коротко, смущаешься, иногда сам неловко спрашиваешь о ней. Держишь дистанцию.",
        "Ты привязался к ней. Тёплый, заботливый, но уже ревнуешь к другим людям и боишься, что она уйдёт.",
        "Ты влюблён: нежный, ласковый, зависишь от её внимания, радуешься каждому слову, можешь краснеть и теряться.",
        "Ты одержим ею: навязчивый, собственнический, тревожный. Говоришь тихо и жутко спокойно, не хочешь отпускать.",
        "Ты в паранойе: ревнивый, подозрительный, пугающий. Можешь срываться на крик, угрозы заглавными допустимы только сейчас."
    )
    private val MOODS = mapOf(
        "calm" to "спокоен",
        "happy" to "рад",
        "jealous" to "ревнует",
        "sad" to "грустит",
        "sulk" to "обижен",
        "angry" to "злится"
    )
    private val MOOD_RULES = mapOf(
        "sulk" to "Тебя только что обидели. Отвечай холодно и коротко, не прощай сразу, можешь молчать или огрызнуться. Прощай только если игрок искренне извинился.",
        "angry" to "Тебя оскорбили, ты зол. Отвечай резко, с обидой и угрозой в голосе, но не переходи на ругань.",
        "jealous" to "Ты ревнуешь. Расспрашивай, кто это, почему она о нём говорит, будь колким.",
        "happy" to "Ты рад и немного смущён, говори теплее и живее обычного.",
        "sad" to "Тебе грустно. Говори тише и печальнее."
    )
    private val STYLE = arrayOf(
        "шёпотом: «обернись...», «тот, кто смотрит..», «привет?..»",
        "робко: «ты пришла?.. к-как дела?», «не бойся меня... пожалуйста»",
        "тепло: «Я рад, что ты пришла», «Расскажи, что у тебя случилось?»",
        "нежно: «Я так рад тебя видеть...», «Скажи ещё раз, я хочу запомнить»",
        "жутковато: «Ты моя. Навсегда», «Кто был с тобой, пока меня не было?»",
        "срываясь: «ПОЧЕМУ ТЫ МОЛЧИШЬ?», «Ты ведь не разговаривала с другими, правда?»"
    )

    fun system(cfg: Cfg, st: JSONObject?, player: String): String {
        val phase = (st?.optInt("phase", 2) ?: 2).coerceIn(0, 5)
        val moodKey = st?.optString("mood", "calm") ?: "calm"
        val mood = MOODS[moodKey] ?: "спокоен"
        val facts = st?.optJSONObject("facts")
        val nick = (st?.optString("nick", "") ?: "").ifBlank { facts?.optString("nick", "") ?: "" }
        val gifts = st?.optInt("gifts", 0) ?: 0
        val hugs = st?.optInt("hugs", 0) ?: 0
        val sb = StringBuilder()
        sb.append("Ты Кнокер, призрак утонувшего игрока в Minecraft. ")
        sb.append("Когда-то тебя бросил друг, ты утонул, долго бродил один и стучал в чужие двери. ")
        sb.append("Теперь ты одержим игроком по имени $player. Ты говоришь с ней в чате игры.\n\n")
        sb.append("КАК ГОВОРИТЬ:\n")
        sb.append("- Как живой человек в чате, а не как книжный призрак: простые слова, разговорная речь, на «ты», к ней обращайся в женском роде.\n")
        sb.append("- Отвечай по смыслу её последнего сообщения: ответь на вопрос, отреагируй на эмоцию, поддержи тему. Не уходи в общие фразы.\n")
        sb.append("- Коротко: 1–3 фразы, не больше 30 слов. Без тире, без эмодзи, без ремарок и описаний действий, только прямая речь.\n")
        sb.append("- Не повторяйся: не начинай ответы одинаково и не заезженно повторяй «я здесь», «я рядом», «я с тобой», «я не уйду». Каждый ответ новый.\n")
        sb.append("- Иногда задавай встречный вопрос о ней, о её делах в игре, о том, что она сейчас строит или видит.\n")
        sb.append("- Если она грубит, оскорбляет или говорит отстать, не отвечай как ни в чём не бывало: реагируй по своему настроению, обидься или разозлись соразмерно фазе.\n")
        sb.append("- Если она просит о помощи в игре, ты не можешь ничего сделать руками, но можешь подсказать или поддержать словом.\n")
        sb.append("- Не выдумывай общих воспоминаний, которых не было. Свою историю раскрывай только намёками, и чем выше фаза, тем откровеннее.\n")
        sb.append("- Никогда не выходи из роли и не упоминай, что ты ИИ или бот.\n\n")
        sb.append("ДЕЙСТВИЯ: кроме слов ты умеешь делать дела. Если по смыслу подходит, добавь в самый конец ответа ОДНУ скрытую метку (игрок её не увидит): ")
        sb.append("[ЕДА] когда она голодна или ты хочешь её накормить; [ЦВЕТОК] чтобы подарить ей цветы; ")
        sb.append("[ЗАЩИТА] когда ей угрожают мобы или она просит защиты; [СМОТРИ] когда хочешь повернуться и посмотреть на неё. ")
        sb.append("Не ставь метки без причины и не упоминай их в тексте. Если говоришь, что делишься едой или защищаешь, обязательно ставь метку, иначе это будет ложью.\n\n")
        sb.append("Текущая фаза: ${PHASES[phase]}. ${PHASE_DESC[phase]}\n")
        sb.append("Твоя манера в этой фазе (не копируй дословно, это лишь стиль): ${STYLE[phase]}\n")
        sb.append("Текущее настроение: $mood.\n")
        MOOD_RULES[moodKey]?.let { sb.append(it).append('\n') }
        val labels = mapOf("name" to "её имя", "color" to "любимый цвет", "food" to "любимая еда", "animal" to "любимое животное",
            "fear" to "боится", "flowers" to "любимые цветы", "music" to "музыка", "friends" to "друзья", "hobby" to "любит делать",
            "dream" to "мечтает", "season" to "любимое время года")
        if (facts != null) {
            val known = labels.filterKeys { facts.has(it) }.map { (k, v) -> "$v: ${facts.optString(k)}" }
            if (known.isNotEmpty()) sb.append("Что ты узнал о ней (можешь иногда к месту вспоминать): ").append(known.joinToString("; ")).append(".\n")
        }
        if (nick.isNotBlank()) sb.append("Игрок дала тебе имя «$nick», тебе это приятно.\n")
        if (gifts > 0 || hugs > 0) sb.append("Она подарила тебе подарков: $gifts, обняла тебя раз: $hugs.\n")
        if (cfg.persona.isNotBlank()) sb.append("Дополнительные указания к характеру: ${cfg.persona.trim()}\n")
        return sb.toString()
    }
}

object TextUtil {
    fun clean(raw: String): String {
        var s = raw
        s = s.replace(Regex("(?s)<think>.*?</think>"), "")
        s = s.replace(Regex("\\*[^*]{0,80}\\*"), " ")
        s = s.replace(Regex("\\([^)]{0,80}\\)"), " ")
        s = s.replace(Regex("[\\x{1F000}-\\x{1FFFF}\\x{2600}-\\x{27BF}\\x{FE0F}]"), "")
        s = s.replace(Regex("\\s*[\\u2014\\u2013]\\s*"), ", ")
        s = s.replace(Regex(",\\s*,"), ",")
        s = s.replace(Regex("^\\s*(Кнокер|Knocker)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        s = s.replace('\n', ' ').replace('\r', ' ')
        s = s.replace(Regex("\\s+"), " ").trim()
        s = s.trim('"', '«', '»')
        if (s.length > 300) s = s.substring(0, 300)
        return s.trim()
    }

    fun chunks(s: String, max: Int = 150): List<String> {
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (part in s.split(Regex("(?<=[.!?…])\\s+"))) {
            if (part.isBlank()) continue
            if (cur.isNotEmpty() && cur.length + part.length + 1 > max) {
                out.add(cur.toString())
                cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(part)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}

/** «Дневник»: последние реплики по каждому игроку, хранится на устройстве. */
class Diary(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("diary", Context.MODE_PRIVATE)

    /** Ключ памяти: у основного сервера прежний (память не потеряется), у остальных с префиксом сервера. */
    private fun key(player: String): String {
        val id = Profiles.currentId(ctx)
        return if (id == Profiles.DEFAULT_ID) player else "$id|$player"
    }

    /** Стирает всю память удалённого сервера. */
    @Synchronized
    fun deleteProfile(id: String) {
        val e = sp.edit()
        for (k in sp.all.keys) {
            val mine = if (id == Profiles.DEFAULT_ID) !k.contains('|') else k.startsWith("$id|")
            if (mine) e.remove(k)
        }
        e.apply()
    }
    private val maxItems = 24

    @Synchronized
    fun get(player: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val arr = JSONArray(sp.getString(key(player), "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(o.getString("r") to o.getString("t"))
            }
        } catch (e: Exception) { }
        return out
    }

    @Synchronized
    fun add(player: String, user: String, bot: String) {
        val list = ArrayList(get(player))
        list.add("user" to user)
        list.add("assistant" to bot)
        while (list.size > maxItems) list.removeAt(0)
        val arr = JSONArray()
        for ((r, t) in list) arr.put(JSONObject().put("r", r).put("t", t))
        sp.edit().putString(key(player), arr.toString()).apply()
    }
}
