package ru.knocker.bridge

import android.util.Base64
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest

interface WsListener {
    fun onConnected(c: WsConn)
    fun onText(t: String)
    fun onDisconnected()
}

/** Минимальный WebSocket-сервер (RFC 6455), одно активное соединение. */
class WsServer(
    private val port: Int,
    private val bindAll: Boolean,
    private val listener: WsListener
) {
    @Volatile private var server: ServerSocket? = null
    @Volatile private var current: WsConn? = null
    @Volatile private var closed = false

    /** Бросает исключение, если порт занят. */
    fun start() {
        val ss = ServerSocket()
        ss.reuseAddress = true
        val addr = InetAddress.getByName(if (bindAll) "0.0.0.0" else "127.0.0.1")
        ss.bind(InetSocketAddress(addr, port))
        server = ss
        val t = Thread({ acceptLoop(ss) }, "ws-accept")
        t.isDaemon = true
        t.start()
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (!closed) {
            val s = try {
                ss.accept()
            } catch (e: Exception) {
                if (!closed) Bus.log("accept: ${e.message}")
                return
            }
            val t = Thread({ serve(s) }, "ws-conn")
            t.isDaemon = true
            t.start()
        }
    }

    private fun serve(sock: Socket) {
        val c = WsConn(sock)
        var announced = false
        try {
            sock.tcpNoDelay = true
            sock.keepAlive = true
            if (!c.handshake()) {
                c.close()
                return
            }
            val old = current
            current = c
            if (old != null && old !== c) old.close()
            announced = true
            listener.onConnected(c)
            c.readLoop { listener.onText(it) }
        } catch (e: Exception) {
            if (!closed) Bus.log("соединение: ${e.message}")
        } finally {
            c.close()
            if (announced && current === c) {
                current = null
                listener.onDisconnected()
            }
        }
    }

    fun stop() {
        closed = true
        try { current?.close() } catch (e: Exception) { }
        try { server?.close() } catch (e: Exception) { }
    }
}

class WsConn(private val sock: Socket) {
    private val input = BufferedInputStream(sock.getInputStream())
    private val output = BufferedOutputStream(sock.getOutputStream())

    private fun readHttpLine(): String? {
        val sb = StringBuilder()
        while (true) {
            val c = input.read()
            if (c < 0) return null
            if (c == '\n'.code) break
            if (c != '\r'.code) sb.append(c.toChar())
            if (sb.length > 8192) return null
        }
        return sb.toString()
    }

    fun handshake(): Boolean {
        val first = readHttpLine() ?: return false
        var key: String? = null
        while (true) {
            val line = readHttpLine() ?: return false
            if (line.isEmpty()) break
            val idx = line.indexOf(':')
            if (idx > 0 && line.substring(0, idx).trim().equals("Sec-WebSocket-Key", ignoreCase = true)) {
                key = line.substring(idx + 1).trim()
            }
        }
        if (key == null) {
            Bus.log("HTTP-запрос без WebSocket: $first")
            val body = "WebSocket only"
            output.write(
                ("HTTP/1.1 400 Bad Request\r\nContent-Length: ${body.length}\r\nConnection: close\r\n\r\n$body")
                    .toByteArray(Charsets.ISO_8859_1)
            )
            output.flush()
            return false
        }
        val sha = MessageDigest.getInstance("SHA-1")
            .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray(Charsets.ISO_8859_1))
        val accept = Base64.encodeToString(sha, Base64.NO_WRAP)
        val resp = "HTTP/1.1 101 Switching Protocols\r\n" +
            "Upgrade: websocket\r\n" +
            "Connection: Upgrade\r\n" +
            "Sec-WebSocket-Accept: $accept\r\n\r\n"
        output.write(resp.toByteArray(Charsets.ISO_8859_1))
        output.flush()
        return true
    }

    private fun readN(n: Int): ByteArray? {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) return null
            off += r
        }
        return buf
    }

    fun readLoop(onText: (String) -> Unit) {
        val msg = ByteArrayOutputStream()
        var msgOp = 0
        while (true) {
            val b0 = input.read()
            if (b0 < 0) return
            val b1 = input.read()
            if (b1 < 0) return
            val fin = (b0 and 0x80) != 0
            val op = b0 and 0x0F
            val masked = (b1 and 0x80) != 0
            var len = (b1 and 0x7F).toLong()
            if (len == 126L) {
                val b = readN(2) ?: return
                len = (((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)).toLong()
            } else if (len == 127L) {
                val b = readN(8) ?: return
                len = 0
                for (i in 0 until 8) len = (len shl 8) or (b[i].toLong() and 0xFF)
            }
            if (len < 0 || len > 4_000_000L) return
            val mask = if (masked) (readN(4) ?: return) else null
            val payload = readN(len.toInt()) ?: return
            if (mask != null) {
                for (i in payload.indices) payload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
            }
            when (op) {
                0x8 -> {
                    try { sendFrame(0x8, ByteArray(0)) } catch (e: Exception) { }
                    return
                }
                0x9 -> sendFrame(0xA, payload)
                0xA -> { }
                else -> {
                    if (op != 0) {
                        msg.reset()
                        msgOp = op
                    }
                    msg.write(payload)
                    if (fin) {
                        if (msgOp == 0x1) onText(String(msg.toByteArray(), Charsets.UTF_8))
                        msg.reset()
                    }
                }
            }
        }
    }

    fun sendText(s: String) = sendFrame(0x1, s.toByteArray(Charsets.UTF_8))

    @Synchronized
    private fun sendFrame(op: Int, data: ByteArray) {
        output.write(0x80 or op)
        val n = data.size
        when {
            n < 126 -> output.write(n)
            n <= 0xFFFF -> {
                output.write(126)
                output.write((n shr 8) and 0xFF)
                output.write(n and 0xFF)
            }
            else -> {
                output.write(127)
                for (i in 7 downTo 0) output.write(((n.toLong() shr (8 * i)) and 0xFF).toInt())
            }
        }
        output.write(data)
        output.flush()
    }

    fun close() {
        try { sock.close() } catch (e: Exception) { }
    }
}
